#include <iostream>
#include "DateTime.h"

int main() {
    DateTime currentDateTime;
    currentDateTime.showDateTime();
    return 0;
}
